'''
all functions return in format total, in_lesson, out_lesson
'''

def get_num_encouragement(conversation, name):
    total = 0
    in_lesson = 0

    for m in conversation:
        if m["sender_name"] == name:
            if m["is_encourage"]:
                total += 1
                if m["in_lesson"]:
                    in_lesson += 1

    return total, in_lesson, total - in_lesson

def get_num_answers(conversation, name):
    total = 0
    in_lesson = 0

    for m in conversation:
        if m["sender_name"] == name:
            if m["is_relevant_to_subject"] and not m["is_question"]:
                total += 1
                if m["in_lesson"]:
                    in_lesson += 1

    return total, in_lesson, total - in_lesson

def get_num_questions(conversation, name):
    total = 0
    in_lesson = 0

    for m in conversation:
        if m["sender_name"] == name:
            if m["is_relevant_to_subject"] and m["is_question"]:
                total += 1
                if m["in_lesson"]:
                    in_lesson += 1

    return total, in_lesson, total - in_lesson

def get_helper_score(conv, name):
    sub_conv_len = 1000
    score = 0
    in_lesson = 0
    #find question answer pairs BY STUDENTS
    for i in range(len(conv)):
        if not (conv[i]["is_question"] and conv[i]["is_relevant_to_subject"]):
            continue
        asker = conv[i]["sender_name"]
        #find whether student gave answer
        for j in range(sub_conv_len):
            if conv[i]["sender_name"] == asker and conv[i]["is_ack"]:
                break
            if conv[i]["sender_name"] == name and conv[i]["is_relevant_to_subject"] and not conv[i]["is_question"]:
                score += 1
                if conv[i]["in_lesson"]:
                    in_lesson += 1
                break
    return score, in_lesson, score - in_lesson



def get_participation_score(conversation, name):
    total = 0
    in_lesson = 0

    for m in conversation:
        if m["sender_name"] == name:
            if m["is_relevant_to_subject"] or m["is_ack"] or m["is_encourage"]:
                total += 1
                if m["in_lesson"]:
                    in_lesson += 1

    return total, in_lesson, total - in_lesson

def get_change_in_student(conversation, name, periods_num, min_slope):
    conversation_samples = sample_conversation(conversation, periods_num)
    questions = []
    samples = []
    encouragements = []
    answers = []
    participation =[]
    for index, sample in enumerate(conversation_samples):
        samples.append(index)
        questions.append(get_num_questions(sample, name))
        encouragements.append(get_num_encouragement(sample, name))
        answers.append(get_num_answers(sample, name))
        participation.append(get_participation_score(sample, name))


    a = 1


def chunks(l, n):
    """Yield successive n-sized chunks from l."""
    for i in range(0, len(l), n):
        yield l[i:i + n]

def sample_conversation(conversation, N_samples):
    num_of_msg_in_conversation = len(conversation)
    chunks_size = num_of_msg_in_conversation//N_samples
    return list(chunks(conversation, chunks_size))


functions = {"encourage":get_num_encouragement,
             "answ":get_num_answers,
             "quest":get_num_questions,
             "helper":get_helper_score,
             "active":get_participation_score}

'''get overall analysis for student'''
def get_student_analysis(conversation, name):
    analysis = {}
    for f in functions:
        analysis[f] = functions[f](conversation, name)
    return analysis